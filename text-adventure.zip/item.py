#!/usr/bin/env python
'''Items'''


class Item:
    def __init__(self, name, bonus):
        self.name = name
        self.bonus = bonus
        self.used = False
